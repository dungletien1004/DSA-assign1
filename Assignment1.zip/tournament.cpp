#ifndef _definition_h_
#include "defs.h"
#define _definition_h_
#endif

ringsignList*  combat (knight& theKnight, eventList* pEvent)
{
	ringsignList* pList = NULL; 
	//fighting for honor and love here
	
  
	return pList;
}

int checkPalindrome(ringsignList* pRingsign)
{
	return 0;
}
